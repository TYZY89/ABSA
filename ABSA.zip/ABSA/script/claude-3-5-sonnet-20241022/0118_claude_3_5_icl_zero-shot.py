import json
from tqdm import tqdm
from openai import OpenAI  # 导入OpenAI客户端

# 初始化OpenAI客户端
client = OpenAI(
    base_url="https://api2.aigcbest.top/v1",
    api_key="sk-MKkYcUXaqnmkbgqO070e38525fAe4545A9E204E962E08a6d"
)

RETRY_TIMES = 3  # 如果请求失败了，尝试的次数

# 系统提示，指定任务的描述
system_prompt = """
 You are an advanced AI model specialized in Aspect-Based Sentiment Analysis (ABSA). Your task is to analyze text and identify sentiment polarity (positive, negative, or neutral) associated with specific aspects or entities mentioned in the text.

Instructions:
1. Carefully read the provided text
2. Identify all aspects/entities and their associated sentiments
3. Return sentiment analysis in the format: [[aspect, sentiment]]
4. If no aspects with clear sentiment are found, return an empty list
5. Classify sentiments strictly as: "positive", "negative", or "neutral".

Input Format: Text
Output Format: A list of aspects and their associated sentiments in the format: [["aspect", "sentiment"]], with no additional explanation or description.

Special Notes:
- Focus on explicit aspects and clear sentiment expressions
- Avoid inferring sentiment where it's ambiguous
- Only identify aspects that have associated sentiment expressions
- Do not summarize or explain the text, focus solely on aspect-sentiment pairs

The following is the input data, please give the output result:
"""

# Define response_format
response_format = {
    "type": "json_schema",
    "json_schema": {
        "name": "absa_response",
        "strict": True,
        "schema": {
            "type": "object",
            "properties": {
                "aspects": {
                    "type": "array",
                    "items": {
                        "type": "array",
                        "items": [
                            {"type": "string"},  # Aspect
                            {"type": "string"}   # Sentiment category
                        ],
                        "minItems": 2,  # Must contain two items (aspect and sentiment)
                        "maxItems": 2
                    }
                }
            },
            "required": ["aspects"],
            "additionalProperties": False
        }
    }
}

# Get response and handle it
def get_response_qwen(text_prompt):
    res = ''
    for i in range(RETRY_TIMES):
        try:
            # Send request to OpenAI client
            response = client.chat.completions.create(
                model="claude-3-5-sonnet-20241022",
                messages=[  # Format the messages to send
                    {
                        "role": "system",
                        "content": system_prompt,
                    },
                    {
                        "role": "user",
                        "content": text_prompt,
                    }
                ],
                max_tokens=1024,  # Maximum response tokens
                response_format=response_format  # Specify response format
            )
            res = response.choices[0].message.content  # Extract response content
            break
        except Exception as e:
            print("Request failed, retrying...", e)  # Error handling, retry
    if res == "":
        print("No result returned, please check!!!")
    return res

# Process each sample and write to JSON immediately
def filter_json(input_json, output_json):
    results = []  # Initialize an empty list to store all the results
    with open(input_json, "r", encoding="utf-8") as infile:
        data = json.load(infile)  # Load entire JSON file as a dictionary or list

        for entry in tqdm(data, desc="Processing progress"):  # Iterate over entries in JSON
            prompt = entry.get("input", "")  # Get the input data

            result = get_response_qwen(prompt)  # Get response from model

            # Append response to entry
            entry["response"] = result
            results.append(entry)  # Add the processed entry to results

    # Write all results to the output file as a valid JSON array
    with open(output_json, "w", encoding="utf-8") as outfile:
        json.dump(results, outfile, ensure_ascii=False, indent=4)

    print(f"Processing complete, results saved to {output_json}")

# Main function
if __name__ == "__main__":
    input_json = r"ABSA\data\res14\test_shargpt.json"  # Input JSON file path
    output_json = r"ABSA\data\res14\claude3_5\test_with_claude35_zero_shot.json"  # Output JSON file path
    filter_json(input_json, output_json)