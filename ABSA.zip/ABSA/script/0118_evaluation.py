import json
from collections import Counter
import logging

# 设置日志记录配置  
logging.basicConfig(
    filename=r"ABSA/data/res14/log/api_llama31_ten-shot.log",
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
)

def load_data(input_json):
    """加载JSON数据文件"""
    try:
        with open(input_json, 'r', encoding='utf-8') as infile:
            data = json.load(infile)
        logging.info(f"Successfully loaded data from {input_json}")
        return data
    except FileNotFoundError:
        logging.error(f"Error: The file {input_json} was not found.")
        raise
    except Exception as e:
        logging.error(f"Error loading data from {input_json}: {e}")
        raise

def normalize_pairs(pairs):
    """标准化aspect-sentiment对，并统计每对的出现次数"""
    return Counter((aspect.lower(), sentiment) for aspect, sentiment in pairs)

def validate_labels(labels):
    """验证标签格式是否正确"""
    valid_labels = {'positive', 'negative', 'neutral'}
    try:
        for aspect, sentiment in labels:
            if not isinstance(aspect, str):
                return False
            if sentiment not in valid_labels:
                return False
        return True
    except:
        return False

def calculate_metrics(data):
    """计算评估指标"""
    # 用于Micro指标计算
    total_true_pairs = 0
    total_pred_pairs = 0
    total_correct_pairs = 0
    
    # 用于Macro指标计算
    sentiment_metrics = {
        'positive': {'TP': 0, 'FP': 0, 'FN': 0},
        'negative': {'TP': 0, 'FP': 0, 'FN': 0},
        'neutral': {'TP': 0, 'FP': 0, 'FN': 0}
    }
    
    # 用于句子级准确率
    total_sentences = 0
    correct_sentences = 0
    
    for entry in data:
        try:
            true_labels = json.loads(entry['output'])
            pred_labels = json.loads(entry['response'])
            
            if not validate_labels(true_labels) or not validate_labels(pred_labels):
                continue
            
            true_counter = normalize_pairs(true_labels)
            pred_counter = normalize_pairs(pred_labels)
            
            # 句子级准确率
            if true_counter == pred_counter:
                correct_sentences += 1
            total_sentences += 1
            
            # Micro指标统计
            for pair, true_count in true_counter.items():
                aspect, sentiment = pair
                pred_count = pred_counter.get(pair, 0)
                min_count = min(true_count, pred_count)
                
                # Micro统计
                total_correct_pairs += min_count
                
                # Macro统计：分情感类别
                sentiment_metrics[sentiment]['TP'] += min_count
                if pred_count > true_count:
                    sentiment_metrics[sentiment]['FP'] += (pred_count - true_count)
                if true_count > pred_count:
                    sentiment_metrics[sentiment]['FN'] += (true_count - pred_count)
            
            # 处理预测中额外的pair
            for pair, pred_count in pred_counter.items():
                if pair not in true_counter:
                    aspect, sentiment = pair
                    sentiment_metrics[sentiment]['FP'] += pred_count
            
            total_true_pairs += sum(true_counter.values())
            total_pred_pairs += sum(pred_counter.values())
            
            # 记录详细信息
            logging.info(f"\nInput text: {entry['input']}")
            logging.info(f"True labels: {dict(true_counter)}")
            logging.info(f"Predicted labels: {dict(pred_counter)}")
            
        except Exception as e:
            logging.error(f"Error processing entry: {str(e)}")
            continue
    
    # 计算Micro指标
    micro_precision = total_correct_pairs / total_pred_pairs if total_pred_pairs > 0 else 0
    micro_recall = total_correct_pairs / total_true_pairs if total_true_pairs > 0 else 0
    micro_f1 = 2 * micro_precision * micro_recall / (micro_precision + micro_recall) if micro_precision + micro_recall > 0 else 0
    
    # 计算Macro指标
    macro_precision = 0
    macro_recall = 0
    macro_f1 = 0
    valid_sentiments = 0
    
    for sentiment, metrics in sentiment_metrics.items():
        if metrics['TP'] + metrics['FP'] + metrics['FN'] > 0:
            precision = metrics['TP'] / (metrics['TP'] + metrics['FP']) if metrics['TP'] + metrics['FP'] > 0 else 0
            recall = metrics['TP'] / (metrics['TP'] + metrics['FN']) if metrics['TP'] + metrics['FN'] > 0 else 0
            f1 = 2 * precision * recall / (precision + recall) if precision + recall > 0 else 0
            
            macro_precision += precision
            macro_recall += recall
            macro_f1 += f1
            valid_sentiments += 1
            
            logging.info(f"\n{sentiment} metrics:")
            logging.info(f"Precision: {precision:.4f}")
            logging.info(f"Recall: {recall:.4f}")
            logging.info(f"F1: {f1:.4f}")
    
    if valid_sentiments > 0:
        macro_precision /= valid_sentiments
        macro_recall /= valid_sentiments
        macro_f1 /= valid_sentiments
    
    # 计算准确率
    accuracy = correct_sentences / total_sentences if total_sentences > 0 else 0
    
    logging.info("\nOverall Statistics:")
    logging.info(f"Total true pairs: {total_true_pairs}")
    logging.info(f"Total predicted pairs: {total_pred_pairs}")
    logging.info(f"Total correct pairs: {total_correct_pairs}")
    logging.info(f"Total sentences: {total_sentences}")
    logging.info(f"Correct sentences: {correct_sentences}")
    
    return (
        accuracy, 
        micro_f1, micro_precision, micro_recall,
        macro_f1, macro_precision, macro_recall
    )

def print_metrics(accuracy, micro_f1, micro_precision, micro_recall, 
                 macro_f1, macro_precision, macro_recall):
    """打印和记录评估指标"""
    metrics = {
        'Micro-F1': micro_f1,
        'Micro-Precision': micro_precision,
        'Micro-Recall': micro_recall,
        'Accuracy': accuracy,
        'Macro-F1': macro_f1,
        'Macro-Precision': macro_precision,
        'Macro-Recall': macro_recall
    }
    
    logging.info("\nEvaluation Metrics:")
    for metric_name, value in metrics.items():
        message = f"{metric_name}: {value:.4f}"
        print(message)
        logging.info(message)
    
    logging.info("="*50 + "\n\n\n\n\n")

if __name__ == "__main__":
    input_json = r"ABSA\data\res14\llama3_1\test_with_llama31_ten_shot.json"

    try:
        data = load_data(input_json)
        metrics = calculate_metrics(data)
        print_metrics(*metrics)
    except Exception as e:
        error_msg = f"An error occurred: {str(e)}"
        logging.error(error_msg)
        print(error_msg)
