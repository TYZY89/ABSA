import json

def convert_data(input_data, note_id):
    """
    将原始数据转换为目标格式
    """
    # 构建输入文本
    input_text = " ".join(input_data["token"])  # 将token列表合成句子
    # 构建输出格式
    output_data = []
    for aspect in input_data["aspects"]:
        term = " ".join(aspect["term"])  # 将term列表拼接成一个字符串
        polarity = aspect["polarity"]
        output_data.append([term, polarity])
    
    # 构建最终的JSON格式
    result = {
        "note_id": f'res14_test_{note_id}',
        "instruction": "",  # 默认为空字符串
        "input": input_text,
        "output": json.dumps(output_data)  # 将output转换为JSON格式字符串
        # "response": json.dumps(output_data)  # 将response同样作为output
    }
    return result

def process_json(input_file, output_file):
    """
    从输入的 JSON 文件中加载数据，处理并保存为输出的 JSON 文件
    """
    # 从文件加载输入数据
    with open(input_file, 'r', encoding='utf-8') as infile:
        data = json.load(infile)
    
    # 处理数据
    converted_data = []
    note_id = 1
    for entry in data:
        converted_data.append(convert_data(entry, note_id))
        note_id += 1
    
    # 将处理后的数据保存到输出文件
    with open(output_file, 'w', encoding='utf-8') as outfile:
        json.dump(converted_data, outfile, ensure_ascii=False, indent=2)

# 示例用法
input_file = r"ABSA\data\res14\test.json"  # 输入 JSON 文件路径
output_file = r"ABSA\data\res14\test_shargpt.json"  # 输出 JSON 文件路径

# 调用处理函数
process_json(input_file, output_file)

print(f"处理完成，输出文件：{output_file}")
