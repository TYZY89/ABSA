import json
import os

def fix_json_format(input_path, output_path):
    """
    Read JSON objects from input file, convert them into a properly formatted JSON array,
    and write to output file
    
    Args:
        input_path (str): Path to input file containing multiple JSON objects
        output_path (str): Path where the formatted JSON array will be saved
    """
    try:
        # Read input file
        with open(input_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # Process each line as a separate JSON object
        json_objects = []
        current_obj = ""
        
        for line in lines:
            line = line.strip()
            if not line:  # Skip empty lines
                continue
                
            current_obj += line
            
            try:
                # Try to parse the accumulated string as JSON
                obj = json.loads(current_obj)
                json_objects.append(obj)
                current_obj = ""  # Reset for next object
            except json.JSONDecodeError:
                continue  # Keep accumulating lines if not valid JSON yet
        
        # Create output directory if it doesn't exist
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        # Write formatted JSON to output file
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(json_objects, f, indent=4, ensure_ascii=False)
            
        print(f"Successfully processed JSON data from {input_path}")
        print(f"Formatted output saved to {output_path}")
        print(f"Processed {len(json_objects)} JSON objects")
        
    except FileNotFoundError:
        print(f"Error: Input file {input_path} not found")
    except Exception as e:
        print(f"Error occurred: {str(e)}")

if __name__ == "__main__":
    # Example usage
    input_path = r"ABSA\data\res14\0118_test_with_claude35_icl_one_shot.json"
    output_path = r"ABSA\data\res14\0118_test_with_claude35_icl_one_shot_fix.json"
    
    fix_json_format(input_path, output_path)

